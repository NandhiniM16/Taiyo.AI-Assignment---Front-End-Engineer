import './App.css';
import Routers from './Routes/Routers';
import Contacts from './components/Contacts';

function App() {
  return (
    <div className="App">
      <Routers/>
    </div>
  );
}

export default App;


export const ADD_CONTACT_SUCCESS="Add_Contacts/addcontact/success"
export const ADD_CONTACT_ERROR="Add_Contacts/addcontact/error"